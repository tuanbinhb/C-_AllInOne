// Server_socket.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Server_socket.h"
#include "afxsock.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		CSocket server, client;
		char s_str[1000], r_str[1000];

		int len;
	
		AfxSocketInit(NULL);

		
		server.Create(1234);
		//server.Create(
		//server.GetLastError
		//server.Create(
		
		server.Listen();


		printf("Dang cho 1 ket noi..\n");

		if (server.Accept(client))
		{
			printf("Da chap nhan 1 ket noi..\n");
			do
			{
				printf("\nServer	: ");
				gets(s_str);
				// goi chieu dai chuoi
				char buff[10];
				itoa(strlen(s_str),buff,10);
				client.Send(buff,10,0);	
				// goi chuoi
				client.Send(s_str,strlen(s_str),0);	


				//
				client.Receive(r_str,10,0);
				int len = atoi(r_str);
				client.Receive(r_str,len,0);
				r_str[len] = 0;
				// gan ket thuc chuoi
				r_str[len] = 0;						
				// hien thi chuoi nhan duoc ra man hinh
				printf("\nCleint: %s",r_str);		

			}while (strcmp(r_str,"exit") && strcmp(s_str,"exit"));

			client.Close();

		}

		server.Close();
	}

	return nRetCode;
}
