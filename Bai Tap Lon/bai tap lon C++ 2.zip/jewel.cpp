//============================================================================
// Name        : jewel.cpp
// Author      : Nguyen Duc Huy
// Version     : 1.0
// Description : Initial code for Assignment 1
// Created on  : Feb 19, 2014
//============================================================================

#include <iostream>
#include <fstream>

using namespace std;

#define ADJCENT_T 1
#define ADJCENT_L 2
#define ADJCENT_B 3
#define ADJCENT_R 4

#define SUCCESS 0
#define FAIL -1

//////////////////////////////////////////////////////////
// Functions definitions								//
//////////////////////////////////////////////////////////

// read initial input
int read_input(char* filename, char** & gameboard, int& m, int& n);

// write user result to file
int write_output(char* filename, int score, char** gameboard, int n);

// write current game status to an output stream
int write_gameboard(ostream &out, char** & gameboard);

//////////////////////////////////////////////////////////
// Global variables										//
//////////////////////////////////////////////////////////

// width and height of matrices
int m, n;

// game board
char** gameboard;

// program entry
int main() {

	// game result
	int score;

	// read input file
	read_input("input.txt", gameboard, m, n);

	// process
	score = 0;

	do {
		// user input
		int x, y, t;
		char T;

		write_gameboard(cout, gameboard);
		cin >> x >> y >> T;

		// exit condition
		if (x == -1 && y == -1 && T == 'A')
			break;

		t = 0;
		switch (T) {
		case 'T':
			t = ADJCENT_T;
			break;
		case 'B':
			t = ADJCENT_B;
			break;
		case 'L':
			t = ADJCENT_L;
			break;
		case 'R':
			t = ADJCENT_R;
			break;
		default:
			// error
			break;
		}

		// TODO

	} while (true);

	// save user result to file
	write_output("output.txt", score, gameboard, n);

	return 0;
}

//////////////////////////////////////////////////////////
// Functions implement									//
//////////////////////////////////////////////////////////

int read_input(char* filename, char** & gameboard, int& m, int& n) {

	// open file to read
	ifstream fin(filename);

	// read column and row
	fin >> n >> m;

	// read initial gameboard
	gameboard = new char*[m];
	for (int i = 0; i < m; i++) {
		gameboard[i] = new char[n];
		for (int j = 0; j < n; j++)
			fin >> gameboard[i][j];
	}
	fin.close();

	return SUCCESS;
}

int write_output(char* filename, int score, char** gameboard, int n) {
	// open file for output
	ofstream fout(filename);

	// write score
	fout << score << endl;

	// write final gameboard
	write_gameboard(fout, gameboard);

	// close file
	fout.close();

	return SUCCESS;
}

int write_gameboard(ostream &out, char** & gameboard) {
	for (int row=n-1; row>=0; row--) {
		for (int col =0; col <n; col++)
			out << gameboard[row][col] << " ";
		out << endl;
	}
	return SUCCESS;
}
