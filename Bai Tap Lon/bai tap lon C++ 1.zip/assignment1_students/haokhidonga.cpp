/**
 * In params: 
 * current_dam1: suc cong pha cua quan Dai Viet.
 * current_dam2: suc cong pha cua quan Nguyen Mong.
 * vk1: vu khi cua quan Dai Viet.
 * vk2: vu khi cua quan Nguyen Mong.
 * ground: dia hinh noi dien ra tran chien.
 * Return value: xac suat thang tran cua quan Dai Viet.
 */
float calculate(int current_dam1,int current_dam2,int vk1,int vk2,int ground)
{
	float pT = 0.99;
	
	// Write your code here!
	
	return pT;
}








