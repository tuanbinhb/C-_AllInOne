#include <stdio.h>
#include <iostream>
#include <fstream>
#include "haokhidonga.cpp"

using namespace std;

//read data from input file to corresponding variables
//return 1 if successfully done, otherwise return 0
int readFile(int& current_dam1,int& current_dam2,int& vk1,int& vk2,int& ground)
{
	char* file_name = "input.txt";
	ifstream in;
	in.open(file_name);
	in >> current_dam1;	
	in >> vk1;	
	in >> current_dam2;	
	in >> vk2;	
	in >> ground;
	in.close();
	if (current_dam1 < 1 || current_dam1 > 999)
		return 0;
	if (current_dam2 < 1 || current_dam2 > 888)
		return 0;
	if ((vk1 < 1)||(vk2 < 1)||(vk1 > 3)||(vk2 > 3))
		return 0;
	if (ground < 1 || ground > 999)
		return 0;
	in.close();
	return 1;
}

void display(float pT)
//display value of pT in format of 0.XX
// no exception handled
{
	if (pT == 1){
		cout << pT;
	}
	else{
		char s[10];
		sprintf(s,"%.2f",pT);
		cout << s;
	}
}

int main(void)
{
	// Do not change anythings in main.
	int current_dam1,current_dam2,vk1,vk2,ground;
	float pT = 0.0;
	readFile(current_dam1,current_dam2,vk1,vk2,ground);	
	pT = calculate(current_dam1,current_dam2,vk1,vk2,ground);
	display(pT);
	return 0;
}






